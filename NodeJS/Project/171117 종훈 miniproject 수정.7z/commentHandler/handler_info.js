// 핸들러에 대한 정보

console.log('handler_info 파일 로딩됨');

var handler_info = [
    {file:'./viewComment', method:'viewComment'}
]

module.exports = handler_info;