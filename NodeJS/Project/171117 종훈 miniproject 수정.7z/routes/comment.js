var loadComment = function(req,res){
    console.log('loadComment 호출');
}


module.exports.loadComment = loadComment;